﻿using System;
using System.Collections.Generic;

namespace Manager
{
    // NOTA: è possibile utilizzare il comando "Rinomina" del menu "Refactoring" per modificare il nome di classe "ShopService" nel codice e nel file di configurazione contemporaneamente.
    public class ShopService : IShopService
    {
        public bool Acquisto(ServiceReference1.Acquisto acquisto)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.Acquisto(acquisto);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool CheckEmail(string email)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.CheckEmail(email);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool EliminaIndirizzo(int id)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.EliminaIndirizzo(id);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool EliminaPreferito(string user, int id)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.EliminaPreferito(user, id);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool EliminaProdotto(int id)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.EliminaProdotto(id);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public string GetCategoria(int id)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.GetCategoria(id);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public ServiceReference1.Utente GetCliente(string id)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.GetCliente(id);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public ServiceReference1.Indirizzo GetIndirizzo(int id)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.GetIndirizzo(id);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public string GetMetodoPagamento(int id)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.GetMetodoPagamento(id);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public string GetMetodoSpedizione(int id)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.GetMetodoSpedizione(id);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public ServiceReference1.Acquisto GetOrdine(int IDordine)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.GetOrdine(IDordine);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public ServiceReference1.Articolo GetProdotto(int IDProdotto)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.GetProdotto(IDProdotto);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public string GetStatoOrdine(int id)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.GetStatoOrdine(id);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public List<string> ListaCap()
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ListaCap();
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public List<int> ListaCategorie()
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ListaCategorie();
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public List<string> ListaClienti()
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ListaClienti();
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public List<int> ListaIndirizzi(string user)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ListaIndirizzi(user);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public List<int> ListaMetodiPagamento()
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ListaMetodiPagamento();
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public List<int> ListaMetodiSpedizione()
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ListaMetodiSpedizione();
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public List<int> ListaOrdini(string user)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ListaOrdini(user);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public List<int> ListaProdotti()
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ListaProdotti();
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public List<int> ListaProdottiDisponibili()
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ListaProdottiDisponibili();
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public List<int> ListaProdottiPreferiti(string user)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ListaProdottiPreferiti(user);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool ModificaIndirizzo(ServiceReference1.Indirizzo indirizzo)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ModificaIndirizzo(indirizzo);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool ModificaPassword(string email, string psw)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ModificaPassword(email, psw);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool ModificaProdotto(ServiceReference1.Articolo prodottoDaModificare)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.ModificaProdotto(prodottoDaModificare);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool NuovaCategoria(string nome)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.NuovaCategoria(nome);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool NuovoIndirizzo(ServiceReference1.Indirizzo nuovo)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.NuovoIndirizzo(nuovo);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool NuovoProdotto(ServiceReference1.Articolo nuovo)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.NuovoProdotto(nuovo);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool NuovoPreferito(string user, int id)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.NuovoPreferito(user, id);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public bool Signin(ServiceReference1.Utente nuovo)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.Signin(nuovo);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public int UserLogin(ServiceReference1.Login user)
        {
            try
            {
                using (ServiceReference1.DbServiceClient conn = new ServiceReference1.DbServiceClient())
                {
                    return conn.UserLogin(user);
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }
    }
}
