﻿using System.Collections.Generic;
using System.ServiceModel;

namespace Manager
{
    // NOTA: è possibile utilizzare il comando "Rinomina" del menu "Refactoring" per modificare il nome di interfaccia "IShopService" nel codice e nel file di configurazione contemporaneamente.
    [ServiceContract]
    public interface IShopService
    {
        [OperationContract]
        bool Acquisto(ServiceReference1.Acquisto acquisto);

        [OperationContract]
        bool CheckEmail(string email);

        [OperationContract]
        bool EliminaIndirizzo(int id);

        [OperationContract]
        bool EliminaPreferito(string user, int id);

        [OperationContract]
        bool EliminaProdotto(int id);

        [OperationContract]
        string GetCategoria(int id);

        [OperationContract]
        ServiceReference1.Utente GetCliente(string id);

        [OperationContract]
        ServiceReference1.Indirizzo GetIndirizzo(int id);

        [OperationContract]
        string GetMetodoPagamento(int id);

        [OperationContract]
        string GetMetodoSpedizione(int id);

        [OperationContract]
        ServiceReference1.Acquisto GetOrdine(int IDordine);

        [OperationContract]
        ServiceReference1.Articolo GetProdotto(int IDProdotto);

        [OperationContract]
        string GetStatoOrdine(int id);

        [OperationContract]
        List<string> ListaCap();

        [OperationContract]
        List<int> ListaCategorie();

        [OperationContract]
        List<string> ListaClienti();

        [OperationContract]
        List<int> ListaIndirizzi(string user);

        [OperationContract]
        List<int> ListaMetodiPagamento();

        [OperationContract]
        List<int> ListaMetodiSpedizione();

        [OperationContract]
        List<int> ListaOrdini(string user);

        [OperationContract]
        List<int> ListaProdotti();

        [OperationContract]
        List<int> ListaProdottiDisponibili();

        [OperationContract]
        List<int> ListaProdottiPreferiti(string user);

        [OperationContract]
        bool ModificaIndirizzo(ServiceReference1.Indirizzo indirizzo);

        [OperationContract]
        bool ModificaPassword(string email, string psw);

        [OperationContract]
        bool ModificaProdotto(ServiceReference1.Articolo prodottoDaModificare);

        [OperationContract]
        bool NuovaCategoria(string nome);

        [OperationContract]
        bool NuovoIndirizzo(ServiceReference1.Indirizzo nuovo);

        [OperationContract]
        bool NuovoPreferito(string user, int id);

        [OperationContract]
        bool NuovoProdotto(ServiceReference1.Articolo nuovo);

        [OperationContract]
        bool Signin(ServiceReference1.Utente nuovo);

        [OperationContract]
        int UserLogin(ServiceReference1.Login user);
    }
}
