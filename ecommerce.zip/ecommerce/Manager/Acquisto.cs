﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Manager
{
    [DataContract]
    public class Acquisto
    {
        [DataMember]
        public int IDacquisto { get; set; }

        [DataMember]
        public List<Articolo> Carrello { get; set; }

        [DataMember]
        public double Importo { get; set; }

        [DataMember]
        public DateTime Data_ora { get; set; }

        [DataMember]
        public int MetodoSpedizione { get; set; }

        [DataMember]
        public int MetodoPagamento { get; set; }

        [DataMember]
        public string User { get; set; }

        [DataMember]
        public int IDindirizzo { get; set; }

        [DataMember]
        public int IDstatoOrdine { get; set; }
    }
}
