﻿using System.Runtime.Serialization;

namespace DbManager
{
    [DataContract]
    public class Indirizzo
    {
        [DataMember]
        public int ID { get; set; }
      
        [DataMember]
        public string Alias { get; set; }
        
        [DataMember]
        public string Nome { get; set; }
        
        [DataMember]
        public string Cognome { get; set; }
       
        [DataMember]
        public string Recapito { get; set; }
       
        [DataMember]
        public string Citta { get; set; }
       
        [DataMember]
        public string Cap { get; set; }
       
        [DataMember]
        public string Provincia { get; set; }
      
        [DataMember]
        public string User { get; set; }
    }
}
