﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DbManager
{
    // NOTA: è possibile utilizzare il comando "Rinomina" del menu "Refactoring" per modificare il nome di interfaccia "IDbService" nel codice e nel file di configurazione contemporaneamente.
    [ServiceContract]
    public interface IDbService
    {
        [OperationContract]
        bool Acquisto(Acquisto acquisto);

        [OperationContract]
        bool CheckEmail(string email);

        [OperationContract]
        bool EliminaIndirizzo(int id);

        [OperationContract]
        bool EliminaPreferito(string user, int id);

        [OperationContract]
        bool EliminaProdotto(int id);

        [OperationContract]
        string GetCategoria(int id);

        [OperationContract]
        Utente GetCliente(string id);

        [OperationContract]
        Indirizzo GetIndirizzo(int id);

        [OperationContract]
        string GetMetodoPagamento(int id);

        [OperationContract]
        string GetMetodoSpedizione(int id);

        [OperationContract]
        Acquisto GetOrdine(int IDordine);

        [OperationContract]
        Articolo GetProdotto(int IDProdotto);

        [OperationContract]
        string GetStatoOrdine(int id);

        [OperationContract]
        List<string> ListaCap();

        [OperationContract]
        List<int> ListaCategorie();

        [OperationContract]
        List<string> ListaClienti();

        [OperationContract]
        List<int> ListaIndirizzi(string user);

        [OperationContract]
        List<int> ListaMetodiPagamento();

        [OperationContract]
        List<int> ListaMetodiSpedizione();

        [OperationContract]
        List<int> ListaOrdini(string user);

        [OperationContract]
        List<int> ListaProdotti();

        [OperationContract]
        List<int> ListaProdottiDisponibili();

        [OperationContract]
        List<int> ListaProdottiPreferiti(string user);

        [OperationContract]
        bool ModificaIndirizzo(Indirizzo indirizzo);

        [OperationContract]
        bool ModificaPassword(string email, string psw);

        [OperationContract]
        bool ModificaProdotto(Articolo prodottoDaModificare);

        [OperationContract]
        bool NuovaCategoria(string nome);

        [OperationContract]
        bool NuovoIndirizzo(Indirizzo nuovo);

        [OperationContract]
        bool NuovoPreferito(string user, int id);

        [OperationContract]
        bool NuovoProdotto(Articolo nuovo);

        [OperationContract]
        bool Signin(Utente nuovo);

        [OperationContract]
        int UserLogin(Login user);
    }
}
