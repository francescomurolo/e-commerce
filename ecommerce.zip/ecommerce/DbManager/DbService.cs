﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace DbManager
{
    // NOTA: è possibile utilizzare il comando "Rinomina" del menu "Refactoring" per modificare il nome di classe "DbService" nel codice e nel file di configurazione contemporaneamente.
    public class DbService : IDbService
    {
        //stringa di connessione
        private static readonly string connString = "Server=DESKTOP-GJJ6U42;Database=ecommerce;integrated security=True;";

        /// <summary>
        /// Effettua l'acquisto
        /// </summary>
        /// <param name="acquisto">Un oggetto di tipo Acquisto che contiene tutti i dati necessari per effettuare un acquisto</param>
        /// <returns>True se l'acquisto è andato a buon fine. False in caso contrario</returns>
        public bool Acquisto(Acquisto acquisto)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        //aggiungo all'importo dell'acquisto il prezzo della spedizione recuperato dal db
                        command1.CommandText = "SELECT costo FROM metodo_spedizione WHERE IDms=" + acquisto.MetodoSpedizione;
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                acquisto.Importo += reader.GetDouble(0);
                            }
                        }
                        //creo l'ordine nel db
                        command1.CommandText = "INSERT INTO ordine(data_ora,IDcliente,IDstatoOrdine) " +
                                               "VALUES(CURRENT_TIMESTAMP,'" + acquisto.User.Trim().ToLower() + "', 1)";
                        if (command1.ExecuteNonQuery() > 0)
                        {
                            int id = 0;
                            //mi ricavo l'id dell'ordine
                            command1.CommandText = "SELECT MAX(ordine.IDordine) FROM ordine";
                            using (SqlDataReader reader = command1.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    id = reader.GetInt32(0);
                                }
                            }
                            //creo la composizione dell'ordine
                            foreach (var p in acquisto.Carrello)
                            {
                                command1.CommandText = "INSERT INTO composizione(IDordine,IDprodotto,quantita) " +
                                                       "VALUES(" + id + "," + p.IDprodotto + "," + p.Quantita + ")";

                                command1.ExecuteNonQuery();
                            }
                            //inserisco nel db i dati della spedizione e del pagamento
                            command1.CommandText = "INSERT INTO spedizione(data_ora,IDMetodoSpedizione,IDordine,IDindirizzo) " +
                                                   "VALUES(CURRENT_TIMESTAMP," + acquisto.MetodoSpedizione + "," + id + ", " + acquisto.IDindirizzo + ");" +
                                                   "INSERT INTO pagamento(data_ora,importo,IDmetodoPagamento,IDordine) " +
                                                   "VALUES(CURRENT_TIMESTAMP," + acquisto.Importo.ToString().Replace(",", ".") + 
                                                    "," + acquisto.MetodoPagamento + "," + id + ")";
                            command1.ExecuteNonQuery();
                            risultato = true;
                        }
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Controlla la presenza dell'email nel sistema
        /// </summary>
        /// <param name="email">Email da controllare</param>
        /// <returns>True se l'email non è presente nel sistema. False in caso contrario</returns>
        public bool CheckEmail(string email)
        {
            try
            {
                bool risultato = true;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT * FROM cliente WHERE cliente.email='" + email.Trim().ToLower() + "'";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            if (reader.HasRows)
                                risultato = false;
                        }
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Elimina l'indirizzo di spedizione
        /// </summary>
        /// <param name = "id" > Identificativo dell'indirizzo</param>
        /// <returns>True se l'indirizzo è stato eliminato con successo. False in caso contrario</returns>
        public bool EliminaIndirizzo(int id)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "DELETE FROM rubrica_indirizzi WHERE IDindirizzo=" + id;
                        if (command1.ExecuteNonQuery() > 0)
                            risultato = true;
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Rimuove un prodotto dai preferiti di un cliente
        /// </summary>
        /// <param name="user">Identificativo del cliente</param>
        /// <param name="id">Identificativo del prodotto</param>
        /// <returns>True se il prodotto viene rimosso con successo. False in caso contrario</returns>
        public bool EliminaPreferito(string user, int id)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "DELETE FROM preferito WHERE IDcliente='" + user.Trim().ToLower() + "' AND IDprodotto=" + id;
                        if (command1.ExecuteNonQuery() > 0)
                            risultato = true;
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }
        
        /// <summary>
        /// Elimina un prodotto (lo rende indisponibile)
        /// </summary>
        /// <param name="id">Identificativo del prodotto da eliminare</param>
        /// <returns>True se il prodotto viene eliminato con successo. False in caso contrario</returns>
        public bool EliminaProdotto(int id)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "UPDATE prodotto SET disponibilita=0 WHERE IDprodotto=" + id;
                        if (command1.ExecuteNonQuery() > 0)
                            risultato = true;
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Nome di una categoria
        /// </summary>
        /// <param name="id">Identificativo della categoria</param>
        /// <returns>Il nome della categoria</returns>
        public string GetCategoria(int id)
        {
            try
            {
                string nome = null;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT nome_categoria FROM categoria WHERE IDcategoria=" + id;
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                nome = reader.GetString(0).TrimEnd().ToUpper();
                            }
                        }
                    }
                    conn.Close();
                }
                return nome;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Dati del cliente
        /// </summary>
        /// <param name="id">Identificativo del cliente</param>
        /// <returns>Oggetto Utente contenente i dati del cliente</returns>
        public Utente GetCliente(string id)
        {
            try
            {
                //creo l'oggetto Utente da restituire
                Utente cliente = new Utente() { Email = id };

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT * FROM cliente WHERE email='" + id.Trim().ToLower() + "'";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                cliente.Email = reader.GetString(0).TrimEnd().ToUpper();
                                cliente.Nome = reader.GetString(1).TrimEnd().ToUpper();
                                cliente.Cognome = reader.GetString(2).TrimEnd().ToUpper();
                                cliente.Indirizzo = reader.GetString(3).TrimEnd().ToUpper();
                                cliente.Data_nascita = reader.GetDateTime(4);
                                cliente.Telefono = reader.GetString(5).TrimEnd().ToUpper();
                                cliente.Cap = reader.GetString(6).TrimEnd().ToUpper();
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco il cliente
                return cliente;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Dati dell' indirizzo
        /// </summary>
        /// <param name="id">Identificativo dell'indirizzo</param>
        /// <returns>Oggetto Indirizzo contenente i dati dell'indirizzo</returns>
        public Indirizzo GetIndirizzo(int id)
        {
            try
            {
                //creo l'oggetto indirizzo
                Indirizzo ind = new Indirizzo();

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT r.*,c.nome_citta,p.provincia " +
                                               "FROM rubrica_indirizzi AS r, citta AS c, provincia AS p " +
                                               "WHERE IDindirizzo=" + id + " AND r.IDcitta=c.IDcitta AND p.IDprovincia=c.IDprovincia";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ind.ID = reader.GetInt32(0);
                                ind.Alias = reader.GetString(1).TrimEnd().ToUpper();
                                ind.Nome = reader.GetString(2).TrimEnd().ToUpper();
                                ind.Cognome = reader.GetString(3).TrimEnd().ToUpper();
                                ind.Recapito = reader.GetString(4).TrimEnd().ToUpper();
                                ind.Cap = reader.GetString(5).TrimEnd().ToUpper();
                                ind.Citta = reader.GetString(7).TrimEnd().ToUpper();
                                ind.Provincia = reader.GetString(8).TrimEnd().ToUpper();
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco l'indirizzo
                return ind;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Descrizione del metodo di pagamento
        /// </summary>
        /// <param name="id">Identificativo del Meotodo di Pagamento</param>
        /// <returns>La stringa contenente la descrizione</returns>
        public string GetMetodoPagamento(int id)
        {
            try
            {
                string metodo = null;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT descrizione FROM metodo_pagamento WHERE IDmp=" + id;
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                metodo = reader.GetString(0).TrimEnd().ToUpper();
                            }
                        }
                    }
                    conn.Close();
                }
                return metodo;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Descrizione del metodo di spedizione
        /// </summary>
        /// <param name="id">Identificativo del metodo di spedizione</param>
        /// <returns>La stringa contenente la descrizione</returns>
        public string GetMetodoSpedizione(int id)
        {
            try
            {
                string metodo = null;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT descrizione FROM metodo_spedizione WHERE IDms=" + id;
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                metodo = reader.GetString(0).TrimEnd().ToUpper();
                            }
                        }
                    }
                    conn.Close();
                }
                return metodo;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Dati dell'ordine
        /// </summary>
        /// <param name="IDordine">Identificativo dell'ordine</param>
        /// <returns>Oggetto Acquisto</returns>
        public Acquisto GetOrdine(int IDordine)
        {
            try
            {
                //creo l'oggetto Acquisto
                Acquisto acquisto = new Acquisto() { IDacquisto = IDordine };
                List<Articolo> listaProdotti = new List<Articolo>();

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT c.IDprodotto, c.quantita FROM composizione as c WHERE c.IDordine=" + IDordine;
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaProdotti.Add(GetProdotto(reader.GetInt32(0)));
                                listaProdotti.Last().Quantita = reader.GetInt32(1);
                            }
                        }
                        acquisto.Carrello = listaProdotti;

                        command1.CommandText = "SELECT o.*, s.IDMetodoSpedizione, s.IDindirizzo, p.IDMetodoPagamento, p.importo " +
                                               "FROM ordine as o, spedizione as s, pagamento as p " +
                                               "WHERE o.IDordine=p.IDordine AND o.IDordine=s.IDordine AND o.IDordine=" + IDordine;
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                acquisto.Data_ora = reader.GetDateTime(1);
                                acquisto.User = reader.GetString(2).TrimEnd().ToUpper();
                                acquisto.IDstatoOrdine = reader.GetInt32(3);
                                acquisto.MetodoSpedizione = reader.GetInt32(4);
                                acquisto.IDindirizzo = reader.GetInt32(5);
                                acquisto.MetodoPagamento = reader.GetInt32(6);
                                acquisto.Importo = reader.GetDouble(7);
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco l'acquisto
                return acquisto;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Dati del prodotto
        /// </summary>
        /// <param name="IDProdotto">Identificativo del prodotto</param>
        /// <returns>Oggetto Articolo</returns>
        public Articolo GetProdotto(int IDProdotto)
        {
            try
            {
                //creo l'oggetto da restituire
                Articolo prodotto = new Articolo() { IDprodotto = IDProdotto };

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT prodotto.*, categoria.nome_categoria FROM prodotto, categoria " +
                                               "WHERE prodotto.IDcategoria=categoria.IDcategoria AND IDprodotto=" + IDProdotto;
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                prodotto.Nome = reader.GetString(1).TrimEnd().ToUpper();
                                prodotto.Descrizione = reader.GetString(2).TrimEnd().ToUpper();

                                prodotto.Disponibilita = reader.GetBoolean(3);
                                prodotto.Prezzo = reader.GetDouble(4);
                                prodotto.Categoria = reader.GetString(6).TrimEnd().ToUpper();
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco il prodotto
                return prodotto;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Stato dell'ordine
        /// </summary>
        /// <param name="id">Identificativo dello stato dell'ordine</param>
        /// <returns>Stringa contenente lo stato</returns>
        public string GetStatoOrdine(int id)
        {
            try
            {
                string stato = null;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT stato_ordine FROM stato_ordine WHERE IDstato=" + id;
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                stato = reader.GetString(0).TrimEnd().ToUpper();
                            }
                        }
                    }
                    conn.Close();
                }
                return stato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Lista dei Cap
        /// </summary>
        /// <returns>Lista dei codici Cap</returns>
        public List<string> ListaCap()
        {
            try
            {
                List<string> lista = new List<string>();
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT IDcitta FROM citta";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                lista.Add(reader.GetString(0));
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco la lista dei cap
                return lista;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Lista delle categorie
        /// </summary>
        /// <returns>Lista degli identificativi delle Categorie</returns>
        public List<int> ListaCategorie()
        {
            try
            {
                List<int> lista = new List<int>();

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT IDcategoria FROM categoria";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                lista.Add(reader.GetInt32(0));
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco la lista degli identificativi delle categorie
                return lista;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Lista dei clienti
        /// </summary>
        /// <returns>Lista degli identificativi dei clienti</returns>
        public List<string> ListaClienti()
        {
            try
            {
                List<string> listaClienti = new List<string>();

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT email FROM cliente";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaClienti.Add(reader.GetString(0).TrimEnd().ToUpper());
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco la lista degli identificativi dei clienti
                return listaClienti;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Lista degli indirizzi di un cliente
        /// </summary>
        /// <param name="user">Identificativo del cliente</param>
        /// <returns>Lista degli identificativi degli indirizzi</returns>
        public List<int> ListaIndirizzi(string user)
        {
            try
            {
                List<int> listaIndirizzi = new List<int>();

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT IDindirizzo FROM rubrica_indirizzi WHERE IDcliente='" + user.Trim().ToLower() + "'";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaIndirizzi.Add(reader.GetInt32(0));
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco la lista degli indentificativi degli indirizzi
                return listaIndirizzi;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Lista dei metodi di pagamento
        /// </summary>
        /// <returns>Lista degli identificativi dei metodi di pagamento</returns>
        public List<int> ListaMetodiPagamento()
        {
            try
            {
                List<int> metodi = new List<int>();

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT IDmp FROM metodo_pagamento";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                metodi.Add(reader.GetInt32(0));
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco la lista degli identificativi dei metodi di pagamento
                return metodi;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Lista dei metodi di spedizione
        /// </summary>
        /// <returns>Lista degli identificativi dei metodi di spedizione</returns>
        public List<int> ListaMetodiSpedizione()
        {
            try
            {
                List<int> metodi = new List<int>();

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT IDms FROM metodo_spedizione";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                metodi.Add(reader.GetInt32(0));
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco la lista degli identificativi dei metodi di pagamento
                return metodi;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Lista degli ordini di un cliente
        /// </summary>
        /// <param name="user">identificativo del cliente</param>
        /// <returns>Lista degli identificativi degli ordini</returns>
        public List<int> ListaOrdini(string user)
        {
            try
            {
                List<int> listaOrdini = new List<int>();
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT IDordine FROM ordine WHERE IDcliente='" + user.Trim().ToLower() + "'";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaOrdini.Add(reader.GetInt32(0));
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco la lista degli identificativi degli ordini di un cliente
                return listaOrdini;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Lista dei prodotti
        /// </summary>
        /// <returns>Lsta degli identificativi dei prodotti</returns>
        public List<int> ListaProdotti()
        {
            try
            {
                List<int> lista = new List<int>();
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT IDprodotto FROM prodotto";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                lista.Add(reader.GetInt32(0));
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco la lista degli identificativi dei prodotti
                return lista;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Lista dei prodotti disponibili
        /// </summary>
        /// <returns>Lista degli identificativi dei prodotti disponibili</returns>
        public List<int> ListaProdottiDisponibili()
        {
            try
            {
                List<int> lista = new List<int>();

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT IDprodotto FROM prodotto WHERE disponibilita=1 ORDER BY IDcategoria,nome";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                lista.Add(reader.GetInt32(0));
                            }
                        }
                    }
                    conn.Close();
                }
                //restituisco la lista degli identificativi dei prodotto disponibili
                return lista;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Lista dei prodotti preferiti di un cliente
        /// </summary>
        /// <param name="user">identificativo del cliente</param>
        /// <returns>Lista degli identificativi dei prodotti preferiti</returns>
        public List<int> ListaProdottiPreferiti(string user)
        {
            try
            {
                List<int> listaProdotti = new List<int>();
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT IDprodotto FROM preferito WHERE IDcliente='" + user.Trim().ToLower() + "'";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaProdotti.Add(reader.GetInt32(0));
                            }
                        }
                    }
                    conn.Close();
                }
                //ritorno la lista
                return listaProdotti;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Modifica l'indirizzo
        /// </summary>
        /// <param name="indirizzo">Oggetto Indirizzo</param>
        /// <returns>True se l'indirizzo è stato modificato. False in caso contrario</returns>
        public bool ModificaIndirizzo(Indirizzo indirizzo)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "UPDATE rubrica_indirizzi SET " +
                                                "alias='" + indirizzo.Alias.Trim().ToLower() + "', " +
                                                "nome='" + indirizzo.Nome.Trim().ToLower() + "', " +
                                                "cognome='" + indirizzo.Cognome.Trim().ToLower() + "', " +
                                                "indirizzo='" + indirizzo.Recapito.Trim().ToLower() + "', " +
                                                "IDcitta='" + indirizzo.Cap + "' " +
                                               "WHERE IDindirizzo=" + indirizzo.ID;
                        if (command1.ExecuteNonQuery() > 0)
                            risultato = true;
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Modifica la password
        /// </summary>
        /// <param name="email">Email dell'utente</param>
        /// <param name="psw">Password dell'utente</param>
        /// <returns>True se la password è stata modificata. False in caso contrario</returns>
        public bool ModificaPassword(string email, string psw)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        int idLogin = 0;
                        command1.CommandText = "SELECT IDlogin FROM cliente WHERE email='" + email.Trim().ToLower() + "'";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                idLogin = reader.GetInt32(0);
                            }
                        }

                        command1.CommandText = "UPDATE account SET " +
                                                "password='" + psw + "' " +
                                               "WHERE IDlogin=" + idLogin;
                        if (command1.ExecuteNonQuery() > 0)
                            risultato = true;
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Modifica il prodotto
        /// </summary>
        /// <param name="prodottoDaModificare">Prodotto da modificare</param>
        /// <returns>True se il prodotto è stato modificato. False in caso contrario</returns>
        public bool ModificaProdotto(Articolo prodottoDaModificare)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        int id_cat = 0;
                        command1.CommandText = "SELECT IDcategoria FROM categoria WHERE nome_categoria='" + prodottoDaModificare.Categoria.Trim().ToLower() + "'";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                id_cat = reader.GetInt32(0);
                            }
                        }
                        int disp = Convert.ToInt32(prodottoDaModificare.Disponibilita);
                        string descrizione;
                        if (prodottoDaModificare.Descrizione == null)
                            descrizione = "...";
                        else
                            descrizione = prodottoDaModificare.Descrizione.Trim().ToLower();

                        command1.CommandText = "UPDATE prodotto SET " +
                                                "nome='" + prodottoDaModificare.Nome.Trim().ToLower() + "', " +
                                                "descrizione='" + descrizione + "', " +
                                                "disponibilita=" + disp +
                                                ", prezzo=" + prodottoDaModificare.Prezzo.ToString().Replace(",", ".") +
                                                ", IDcategoria=" + id_cat +
                                               " WHERE IDprodotto=" + prodottoDaModificare.IDprodotto;
                        if (command1.ExecuteNonQuery() > 0)
                            risultato = true;
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Crea una nuova categoria
        /// </summary>
        /// <param name="nome">Nome categoria</param>
        /// <returns>True se la categoria è stata creata. False in caso contrario</returns>
        public bool NuovaCategoria(string nome)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "INSERT INTO categoria(nome_categoria) VALUES('" + nome.Trim().ToLower() + "')";
                        if (command1.ExecuteNonQuery() > 0)
                            risultato = true;
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Crea un nuovo indirizzo
        /// </summary>
        /// <param name="nuovo">Oggetto di tipo Indirizzo</param>
        /// <returns>True se l'indirizzo è stato creato. False in caso contrario</returns>
        public bool NuovoIndirizzo(Indirizzo nuovo)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "INSERT INTO rubrica_indirizzi(alias,nome,cognome,indirizzo,IDcitta,IDcliente) " +
                            "VALUES('" + nuovo.Alias.Trim().ToLower() + "','" + nuovo.Nome.Trim().ToLower() +
                            "','" + nuovo.Cognome.Trim().ToLower() + "','" + nuovo.Recapito.Trim().ToLower() +
                            "','" + nuovo.Cap + "','" + nuovo.User.Trim().ToLower() + "')";
                        if (command1.ExecuteNonQuery() > 0)
                            risultato = true;
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Aggiunge il prodotto ai preferiti di un cliente
        /// </summary>
        /// <param name="user">Identificativo del cliente</param>
        /// <param name="id">Identificativo del prodotto</param>
        /// <returns>True se il prodotto viene aggiunto ai preferiti. False in caso contrario</returns>
        public bool NuovoPreferito(string user, int id)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "INSERT INTO preferito(IDcliente,IDprodotto) VALUES('" + user.Trim().ToLower() + "'," + id + ")";
                        if (command1.ExecuteNonQuery() > 0)
                            risultato = true;
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Crea un nuovo prodotto
        /// </summary>
        /// <param name="nuovo">Oggetto di tipo Articolo</param>
        /// <returns>True se il prodotto è stato creato. False in caso contrario</returns>
        public bool NuovoProdotto(Articolo nuovo)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        int id_cat = 0;
                        command1.CommandText = "SELECT IDcategoria FROM categoria WHERE nome_categoria='" + nuovo.Categoria.Trim().ToLower() + "'";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                id_cat = reader.GetInt32(0);
                            }
                        }
                        int disp = Convert.ToInt32(nuovo.Disponibilita);
                        string descrizione;
                        if (nuovo.Descrizione == null)
                            descrizione = "...";
                        else
                            descrizione = nuovo.Descrizione.Trim().ToLower();

                        command1.CommandText = "INSERT INTO prodotto(nome,descrizione,disponibilita,prezzo,IDcategoria) " +
                                               "VALUES( " + "'" + nuovo.Nome.Trim().ToLower() + "','" + 
                                                descrizione + "'," + disp + "," + 
                                                nuovo.Prezzo.ToString().Replace(",", ".") + "," + id_cat + ")";
                        if (command1.ExecuteNonQuery() > 0)
                            risultato = true;
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Registrazione cliente
        /// </summary>
        /// <param name="nuovo">Oggetto di tipo Utente</param>
        /// <returns>True se l'utente è stato creato con successo. False in caso contrario</returns>
        public bool Signin(Utente nuovo)
        {
            try
            {
                bool risultato = false;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "INSERT INTO account(password) VALUES('" + nuovo.Psw + "')";
                        if (command1.ExecuteNonQuery() > 0)
                        {
                            command1.CommandText = "SELECT MAX(account.IDlogin) FROM account";
                            int id = 0;
                            using (SqlDataReader reader = command1.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    id = reader.GetInt32(0);
                                }
                            }
                            command1.CommandText = "INSERT INTO cliente(email,nome,cognome,indirizzo,data_nascita,telefono,IDcitta,IDlogin) " +
                                                   "VALUES('" + nuovo.Email.Trim().ToLower() +
                                                    "','" + nuovo.Nome.Trim().ToLower() + "','" + nuovo.Cognome.Trim().ToLower() +
                                                    "','" + nuovo.Indirizzo.Trim().ToLower() + "','" + nuovo.Data_nascita +
                                                    "','" + nuovo.Telefono.Trim() + "','" + nuovo.Cap + "'," + id + ")";
                            if (command1.ExecuteNonQuery() > 0)
                                risultato = true;
                        }
                    }
                    conn.Close();
                }
                return risultato;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Login utente
        /// </summary>
        /// <param name="user">Oggetto di tipo Login</param>
        /// <returns>0 se le credenziali sono errate. 1 se l'accesso è stato effettuato dall'admin. 2 se l'accesso è stato effettuato dal cliente</returns>
        public int UserLogin(Login user)
        {
            try
            {
                int codice = 0;
                using (SqlConnection conn = new SqlConnection(connString))
                {

                    conn.Open();
                    using (SqlCommand command1 = conn.CreateCommand())
                    {
                        command1.CommandText = "SELECT * FROM account JOIN amministratore ON account.IDlogin=amministratore.IDlogin " +
                                               "WHERE amministratore.email='" + user.Email.Trim().ToLower() + "' AND account.password='" + user.Password + "'";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            if (reader.HasRows)
                                codice = 1;
                        }
                        command1.CommandText = "SELECT * FROM account JOIN cliente ON account.IDlogin=cliente.IDlogin " +
                                               "WHERE cliente.email='" + user.Email.Trim().ToLower() + "' AND account.password='" + user.Password + "'";
                        using (SqlDataReader reader = command1.ExecuteReader())
                        {
                            if (reader.HasRows)
                                codice = 2;
                        }
                    }
                    conn.Close();
                }
                return codice;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }
    }
}
