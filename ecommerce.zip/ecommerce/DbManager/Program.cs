﻿using System;
using System.ServiceModel;

namespace DbManager
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                using (ServiceHost host = new ServiceHost(typeof(DbService)))
                {
                    host.Open();
                    Console.WriteLine("Database Manager aperto");
                    Console.WriteLine("<Premi un tasto per chiudere il server>");
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore: " + ex.ToString());
            }
        }
    }
}
